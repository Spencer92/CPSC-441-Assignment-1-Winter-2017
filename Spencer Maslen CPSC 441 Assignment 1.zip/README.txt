README

Created By: Spencer Maslen

Limitations: Does not work with pdf files, only works reliably with txt files

If any questions about the code are asked, answers can be supplied without hesitation.